README for Windows

Make sure that the data folder is inside the same folder as trapPuzzler.exe
If you run the game from the command line, make sure to run it when you are in the directory where trapPuzzler.exe is located.


