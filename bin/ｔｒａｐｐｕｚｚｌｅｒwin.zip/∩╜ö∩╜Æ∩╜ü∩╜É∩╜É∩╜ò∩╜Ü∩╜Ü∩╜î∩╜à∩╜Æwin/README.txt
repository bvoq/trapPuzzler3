README for Windows
Make sure to have the game unzipped and check whether the data folder is inside the same folder as ｔｒａｐｐｕｚｚｌｅｒ.exe
If you run the game from the command line, make sure to run it when you are in the directory where trapPuzzler.exe is located.


