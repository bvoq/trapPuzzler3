How to install trappuzzler
==========================

1. Install vcredist_x64_2013.exe (contains vcomp120.dll)
2. Install vcredist_x64_2017.exe (contains other required dll's)
3. Run trappuzzlervs.exe

More information:
Usually these are merged into one big installer, but since there are only two installers.
If you don't trust my source, you can also google for the installers yourself:
Visual C++ Redistributable Packages for Visual Studio 2013
Visual C++ Redistributable Packages for Visual Studio 2017

If you already have Visual Studio installed you might be able to already run trappuzzlervs.exe without needing to install these.